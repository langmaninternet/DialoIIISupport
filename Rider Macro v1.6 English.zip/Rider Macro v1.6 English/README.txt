Guidance of Bazooka Wiz Macro

1. Item setting

- Basically, you can follow the settings of the four-member Leaderboard.

- You need at least 62.60% CDR (in town)


2. Description of macro functions

- Please set all keys, but they must be set to a different key.

- When you're done setting the key, press the START button. Then Everything is ready

- Stack the Gogok at least 10sq, click the key you set with Full Macro at Lightening 1 o'clock ~ 10 o'clock. (both I, II)

- Full Macro I - Everything runs automatically (Using blackhole, Electro, power wave, Making oculus, dealing at arcane, transforming into Arcon, etc..). And repeat exactly 32 sec. All you have to do is move your mouse cursor and character with 'Force Move Key'

- Full Macro II - Dealing only at arcane automatically and repeat exactly 32 sec. You have to make oculus by yourself. 

- It will take some practice to use it freely, But if you can handle it properly this macro will be very useful



3. Caution

- As I said, you must set all keys to different.

- Do not press any other key like Shift key or move force key when start the macro.

- Do not press any other key without move force key when macro is doing something.

- When using move force key, do not hold it down. Just click once. Overlapping the keys pressed by the macro can cause errors.



If you have any other questions, please give me a personal message